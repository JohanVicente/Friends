'use strict';
(function(){

class VehiculosCreateComponent {
  constructor(vehiculosService) {
    this.vehiculosService = vehiculosService;
  }

  vehiculoCreate(){
  	this.vehiculosService.save(this.vehiculo).$promise
  	.then(response => {
  		console.log("vehiculo registrado correctamente ",response);
  	})
  	.catch(err=>{
  		console.log("Error al crear el vehiculo ",err);
  	})
  }
}

angular.module('palmiConApp')
  .component('vehiculosCreate', {
    templateUrl: 'app/vehiculos/vehiculos-create/vehiculos-create.html',
    controller: VehiculosCreateComponent,
    controllerAs:'vm'
  });

})();
