'use strict';

function vehiculosService(API,$resource) {
  return $resource(API+'/vehiculos/:id',{
    id:'@id'
  },{
    update:{
      method:'PUT'
    }
  });
}

angular.module('palmiConApp')
  .factory('vehiculosService', vehiculosService);
